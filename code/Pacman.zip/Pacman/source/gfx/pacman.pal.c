//Palette created using Mollusk's PAGfxConverter

const unsigned short pacman_Pal[2] __attribute__ ((aligned (4))) = {
64543, 33791};
