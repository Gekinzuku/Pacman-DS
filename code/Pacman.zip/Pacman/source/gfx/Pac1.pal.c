//Palette created using Mollusk's PAGfxConverter

const unsigned short Pac1_Pal[3] __attribute__ ((aligned (4))) = {
64543, 36989, 32768};
