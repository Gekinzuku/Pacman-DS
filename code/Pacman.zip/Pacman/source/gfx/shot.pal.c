//Palette created using Mollusk's PAGfxConverter

const unsigned short shot_Pal[3] __attribute__ ((aligned (4))) = {
64543, 65535, 32799};
