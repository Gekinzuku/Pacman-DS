//Sprite created using PAGfx
//This sprite uses shot_Pal

const unsigned char shot_Sprite[32] __attribute__ ((aligned (4))) = {
0, 17, 17, 0, 16, 34, 34, 1, 33, 34, 34, 18, 33, 34, 34, 18, 
33, 34, 34, 18, 33, 34, 34, 18, 16, 34, 34, 1, 0, 17, 17, 0
};

